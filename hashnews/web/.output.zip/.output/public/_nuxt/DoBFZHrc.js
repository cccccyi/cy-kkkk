import"./_mYDD6fH.js";const r=""+new URL("ndlight.D6__7qPM.png",import.meta.url).href,n=""+new URL("nddark.tW6FhvzF.png",import.meta.url).href;export{r as _,n as a};
