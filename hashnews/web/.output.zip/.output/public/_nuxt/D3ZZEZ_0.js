import"./_mYDD6fH.js";const r=""+new URL("cbtc.C5TRyjF8.png",import.meta.url).href,o=""+new URL("xlink.BRv6fbaC.png",import.meta.url).href;export{r as _,o as a};
